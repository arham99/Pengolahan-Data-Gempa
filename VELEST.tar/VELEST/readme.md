
Source of velet can be found in http://www.seg.ethz.ch/software/velest.html

code downloaded on 04/02/2019


Requeriments
------------

Install gfortran and devtools (make, gcc, etc) in your system, in debian/ubuntu you can do:

	sudo apt-get install build-essential gfortran

on fedora 

	sudo yum install gcc-gfortran

after you can clone this repository by doing:

	git clone https://github.com/jubenjum/velest	

or getting the zip file:

	wget -c https://github.com/jubenjum/velest/archive/master.zip

Compile
-------

Compile the code by running

	make 

The generated executable file is `bin/velest` 


